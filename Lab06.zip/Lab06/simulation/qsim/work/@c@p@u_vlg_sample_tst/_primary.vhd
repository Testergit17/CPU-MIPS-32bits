library verilog;
use verilog.vl_types.all;
entity CPU_vlg_sample_tst is
    port(
        CLK             : in     vl_logic;
        CLR             : in     vl_logic;
        sel             : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end CPU_vlg_sample_tst;
