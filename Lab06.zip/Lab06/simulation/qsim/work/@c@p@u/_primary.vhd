library verilog;
use verilog.vl_types.all;
entity CPU is
    port(
        result          : out    vl_logic_vector(15 downto 0);
        CLK             : in     vl_logic;
        CLR             : in     vl_logic;
        sel             : in     vl_logic_vector(2 downto 0)
    );
end CPU;
