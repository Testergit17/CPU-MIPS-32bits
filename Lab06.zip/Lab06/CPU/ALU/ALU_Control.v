module ALU_Control (
    input [2:0] ALUOp,
    input [5:0] funct,
    output reg [2:0] ALU_Sel
);

always @(*) begin
    case (ALUOp)
        3'b000: ALU_Sel = 3'b001;
        3'b001: ALU_Sel = 3'b000;
        3'b010: ALU_Sel = 3'b010;
        3'b011: ALU_Sel = 3'b011;
        3'b100: begin
            case (funct)
                6'h20: ALU_Sel = 3'b001;
                6'h22: ALU_Sel = 3'b000;
                6'h24: ALU_Sel = 3'b010;
                6'h25: ALU_Sel = 3'b011;
                6'h27: ALU_Sel = 3'b100;
                6'h00: ALU_Sel = 3'b101;
                6'h02: ALU_Sel = 3'b110;
                default: ALU_Sel = 3'b001;
            endcase
        end
        default: ALU_Sel = 3'b001;
    endcase
end

endmodule